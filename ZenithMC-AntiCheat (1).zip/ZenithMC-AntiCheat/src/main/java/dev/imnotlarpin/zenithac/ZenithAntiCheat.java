package dev.imnotlarpin.zenithac;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class ZenithAntiCheat extends JavaPlugin {

    private static final MiniMessage MM = MiniMessage.miniMessage();

    private ChatFilter chat;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        FlyCheck fly = new FlyCheck(this);
        chat = new ChatFilter(this);
        Bukkit.getPluginManager().registerEvents(fly, this);
        Bukkit.getPluginManager().registerEvents(chat, this);
        fly.start();
    }

    Component mm(String s) {
        return MM.deserialize(s);
    }

    /** Escape player-written text before putting it in a MiniMessage string. */
    String escape(String s) {
        return MM.escapeTags(s);
    }

    /** Detailed line for staff; a short line for everyone else when alerts.broadcast-flags is on. */
    void flagAlert(String staffLine, String publicLine) {
        String prefix = getConfig().getString("alert-prefix", "<red>[ZenithMC AC]</red> ");
        boolean broadcast = getConfig().getBoolean("alerts.broadcast-flags", true);
        Component staff = mm(prefix + staffLine);
        Component pub = mm(prefix + publicLine);
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.hasPermission("zenithac.alerts")) p.sendMessage(staff);
            else if (broadcast) p.sendMessage(pub);
        }
        Bukkit.getConsoleSender().sendMessage(staff);
    }

    void alertStaff(String msg) {
        Component c = mm(getConfig().getString("alert-prefix", "<red>[ZenithMC AC]</red> ") + msg);
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.hasPermission("zenithac.alerts")) p.sendMessage(c);
        }
        Bukkit.getConsoleSender().sendMessage(c);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!sender.hasPermission("zenithac.admin")) {
            sender.sendMessage(mm("<red>No permission."));
            return true;
        }
        if (args.length >= 1 && args[0].equalsIgnoreCase("reload")) {
            reloadConfig();
            chat.load();
            sender.sendMessage(mm("<green>ZenithMC Anti Cheat reloaded."));
        } else if (args.length >= 2 && args[0].equalsIgnoreCase("unmute")) {
            OfflinePlayer target = Bukkit.getOfflinePlayerIfCached(args[1]);
            if (target == null) {
                sender.sendMessage(mm("<red>Unknown player: " + escape(args[1])));
            } else if (chat.unmute(target.getUniqueId())) {
                sender.sendMessage(mm("<green>Unmuted " + escape(args[1]) + "."));
            } else {
                sender.sendMessage(mm("<gray>" + escape(args[1]) + " is not muted."));
            }
        } else {
            sender.sendMessage(mm("<gray>Usage: /zenithac reload | /zenithac unmute <player>"));
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (!sender.hasPermission("zenithac.admin")) return out;
        if (args.length == 1) {
            for (String s : List.of("reload", "unmute")) {
                if (s.startsWith(args[0].toLowerCase(Locale.ROOT))) out.add(s);
            }
        } else if (args.length == 2 && args[0].equalsIgnoreCase("unmute")) {
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (p.getName().toLowerCase(Locale.ROOT).startsWith(args[1].toLowerCase(Locale.ROOT))) {
                    out.add(p.getName());
                }
            }
        }
        return out;
    }
}
