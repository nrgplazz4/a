package dev.imnotlarpin.zenithac;

import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.SignChangeEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;

import java.io.File;
import java.io.IOException;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Chat, filtered commands and signs. Strikes decay, mutes survive restarts. */
final class ChatFilter implements Listener {

    private static final PlainTextComponentSerializer PLAIN = PlainTextComponentSerializer.plainText();

    private static final class Strikes {
        int count;
        long last;
    }

    private final ZenithAntiCheat plugin;
    private final File mutesFile;
    private volatile ChatScanner scanner;
    private final Map<UUID, Strikes> strikes = new ConcurrentHashMap<>();
    private final Map<UUID, Long> mutes = new ConcurrentHashMap<>();

    ChatFilter(ZenithAntiCheat plugin) {
        this.plugin = plugin;
        this.mutesFile = new File(plugin.getDataFolder(), "mutes.yml");
        load();
        loadMutes();
    }

    void load() {
        FileConfiguration c = plugin.getConfig();
        scanner = new ChatScanner(
                c.getStringList("chat.strict-words"),
                c.getStringList("chat.cuss-substring"),
                c.getStringList("chat.cuss-whole"),
                c.getStringList("chat.allowed-words"));
    }

    // ---------------------------------------------------------------- listeners

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onChat(AsyncChatEvent e) {
        if (blocked(e.getPlayer(), PLAIN.serialize(e.message()))) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onCommand(PlayerCommandPreprocessEvent e) {
        String raw = e.getMessage();
        int space = raw.indexOf(' ');
        if (!raw.startsWith("/") || space < 0) return;

        String cmd = raw.substring(1, space).toLowerCase(Locale.ROOT);
        int colon = cmd.indexOf(':');
        if (colon >= 0) cmd = cmd.substring(colon + 1);
        if (!plugin.getConfig().getStringList("chat.filter-commands").contains(cmd)) return;

        if (blocked(e.getPlayer(), raw.substring(space + 1))) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onSign(SignChangeEvent e) {
        StringBuilder text = new StringBuilder();
        for (Component line : e.lines()) text.append(PLAIN.serialize(line)).append(' ');
        if (blocked(e.getPlayer(), text.toString())) e.setCancelled(true);
    }

    // ---------------------------------------------------------------- core

    /** Returns true if the text must not go through. Handles muted players, strikes and mutes. */
    private boolean blocked(Player p, String text) {
        FileConfiguration c = plugin.getConfig();
        if (!c.getBoolean("chat.enabled", true) || p.hasPermission("zenithac.bypass")) return false;

        long now = System.currentTimeMillis();
        long left = muteMillisLeft(p.getUniqueId(), now);
        if (left > 0) {
            p.sendMessage(plugin.mm(c.getString("chat.muted-message", "<red>You are muted.")
                    .replace("<time>", format(left / 1000))));
            return true;
        }

        if (!scanner.isBlocked(text)) return false;

        int max = c.getInt("chat.strikes-before-mute", 3);
        long decayMs = c.getLong("chat.strike-decay-seconds", 600) * 1000;
        int count = addStrike(p.getUniqueId(), now, decayMs);

        if (c.getBoolean("chat.alert-staff", true)) {
            plugin.alertStaff("<white>" + p.getName() + "</white> <gray>blocked: " + plugin.escape(text));
        }

        if (count >= max) {
            strikes.remove(p.getUniqueId());
            long seconds = c.getLong("chat.mute-seconds", 300);
            mutes.put(p.getUniqueId(), now + seconds * 1000);
            saveMutes();
            p.sendMessage(plugin.mm(c.getString("chat.mute-message", "<red>You are muted.")
                    .replace("<time>", format(seconds))));
        } else {
            p.sendMessage(plugin.mm(c.getString("chat.warn-message", "<red>Watch your language!")
                    .replace("<strikes>", String.valueOf(count)).replace("<max>", String.valueOf(max))));
        }
        return true;
    }

    private int addStrike(UUID id, long now, long decayMs) {
        int[] result = new int[1];
        strikes.compute(id, (k, s) -> {
            if (s == null || now - s.last > decayMs) s = new Strikes();
            s.count++;
            s.last = now;
            result[0] = s.count;
            return s;
        });
        return result[0];
    }

    private long muteMillisLeft(UUID id, long now) {
        Long until = mutes.get(id);
        if (until == null) return 0;
        if (until <= now) {
            mutes.remove(id);
            saveMutes();
            return 0;
        }
        return until - now;
    }

    /** Used by /zenithac unmute. Returns whether the player was muted. */
    boolean unmute(UUID id) {
        strikes.remove(id);
        boolean was = mutes.remove(id) != null;
        if (was) saveMutes();
        return was;
    }

    private static String format(long seconds) {
        return seconds >= 60 ? (seconds / 60) + "m " + (seconds % 60) + "s" : seconds + "s";
    }

    // ---------------------------------------------------------------- persistence

    private void loadMutes() {
        if (!mutesFile.exists()) return;
        YamlConfiguration yml = YamlConfiguration.loadConfiguration(mutesFile);
        long now = System.currentTimeMillis();
        for (String key : yml.getKeys(false)) {
            try {
                long until = yml.getLong(key);
                if (until > now) mutes.put(UUID.fromString(key), until);
            } catch (IllegalArgumentException ignored) {
                // bad key in the file, skip it
            }
        }
    }

    private synchronized void saveMutes() {
        YamlConfiguration yml = new YamlConfiguration();
        for (Map.Entry<UUID, Long> entry : mutes.entrySet()) yml.set(entry.getKey().toString(), entry.getValue());
        try {
            plugin.getDataFolder().mkdirs();
            yml.save(mutesFile);
        } catch (IOException ex) {
            plugin.getLogger().warning("Could not save mutes.yml: " + ex.getMessage());
        }
    }
}
