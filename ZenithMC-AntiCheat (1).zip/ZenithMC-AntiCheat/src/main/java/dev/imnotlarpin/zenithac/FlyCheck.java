package dev.imnotlarpin.zenithac;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Tag;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerRiptideEvent;
import org.bukkit.event.player.PlayerToggleFlightEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.player.PlayerVelocityEvent;
import org.bukkit.event.vehicle.VehicleExitEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Bukkit side of the fly check. The physics lives in {@link FlyModel}; this class feeds it moves,
 * works out who is exempt (flying, gliding, in water, just launched...), and handles setbacks.
 */
final class FlyCheck implements Listener {

    /** Blocks that change how a player moves vertically. Standing in or on these is never judged. */
    private static final Set<Material> SPECIAL = EnumSet.of(
            Material.WATER, Material.LAVA, Material.BUBBLE_COLUMN, Material.COBWEB, Material.HONEY_BLOCK,
            Material.POWDER_SNOW, Material.SWEET_BERRY_BUSH);

    private static final int STICKY_TICKS = 20;   // keep exemption this long after the cause goes away
    private static final int BOUNCE_TICKS = 60;   // after standing on slime or a bed

    private static final class PlayerState {
        final FlyModel model = new FlyModel();
        Location lastGround;
        int exemptUntil;
        int lastMoveTick;
        int lastAlertTick = -1000;
        int lastSetbackTick = -100000;
        int setbacks;
        boolean wasExempt;
        boolean ownTeleport;
        boolean bypass;
        int bypassCheckedTick = -1000;

        PlayerState(int tick) {
            lastMoveTick = tick;
            exemptUntil = tick + 60; // joining: chunks loading, position settling
        }
    }

    private final ZenithAntiCheat plugin;
    private final Map<UUID, PlayerState> states = new HashMap<>();

    FlyCheck(ZenithAntiCheat plugin) {
        this.plugin = plugin;
    }

    void start() {
        Bukkit.getScheduler().runTaskTimer(plugin, this::stallTick, 20L, 2L);
    }

    // ---------------------------------------------------------------- movement

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        if (!e.hasChangedPosition()) return;
        FileConfiguration cfg = plugin.getConfig();
        if (!cfg.getBoolean("fly.enabled", true)) return;

        Player p = e.getPlayer();
        Location from = e.getFrom();
        Location to = e.getTo();
        PlayerState s = state(p);
        int tick = Bukkit.getCurrentTick();
        s.lastMoveTick = tick;

        if (from.getWorld() != to.getWorld() || !to.isChunkLoaded()) {
            s.model.unsettle();
            return;
        }

        boolean exempt = isExempt(p, s, to, tick);
        boolean ground = Ground.standing(to);
        if (ground) {
            s.lastGround = to.clone();
            Material under = to.clone().subtract(0, 0.1, 0).getBlock().getType();
            if (under == Material.SLIME_BLOCK || Tag.BEDS.isTagged(under)) {
                s.exemptUntil = Math.max(s.exemptUntil, tick + BOUNCE_TICKS); // bouncy
            }
        }
        if (s.wasExempt && !exempt) s.model.unsettle();
        s.wasExempt = exempt;

        FlyModel.Result result = s.model.onMove(to.getY() - from.getY(), ground, jumpBoost(p), exempt,
                cfg.getDouble("fly.tolerance", 0.03));

        if (result != FlyModel.Result.OK && s.model.vl() >= cfg.getDouble("fly.flag-threshold", 5.0)) {
            flag(p, s, tick, result == FlyModel.Result.JUMP ? "jump" : "physics", e, to);
        }
    }

    /**
     * A player who is airborne but sends no movement at all (perfect hover) never triggers PlayerMoveEvent,
     * so check for that separately a few times a second.
     */
    private void stallTick() {
        FileConfiguration cfg = plugin.getConfig();
        if (!cfg.getBoolean("fly.enabled", true)) return;
        if (Bukkit.getTPS()[0] < cfg.getDouble("fly.min-tps", 17.0)) return;

        int tick = Bukkit.getCurrentTick();
        int stall = cfg.getInt("fly.stall-ticks", 12);
        double threshold = cfg.getDouble("fly.flag-threshold", 5.0);

        for (Player p : Bukkit.getOnlinePlayers()) {
            PlayerState s = states.get(p.getUniqueId());
            if (s == null || tick - s.lastMoveTick < stall) continue;
            Location loc = p.getLocation();
            if (!loc.isChunkLoaded() || isExempt(p, s, loc, tick) || Ground.standing(loc)) continue;

            s.model.stall();
            if (s.model.vl() >= threshold) {
                s.lastMoveTick = tick;
                flag(p, s, tick, "hover", null, loc);
            }
        }
    }

    // ---------------------------------------------------------------- exemptions

    private boolean isExempt(Player p, PlayerState s, Location loc, int tick) {
        if (tick < s.exemptUntil) return true;

        if (tick - s.bypassCheckedTick >= 100) {
            s.bypass = p.hasPermission("zenithac.bypass")
                    || (plugin.getConfig().getBoolean("fly.exempt-ops", true) && p.isOp());
            s.bypassCheckedTick = tick;
        }
        if (s.bypass) return true;

        GameMode gm = p.getGameMode();
        boolean cause = gm == GameMode.CREATIVE || gm == GameMode.SPECTATOR
                || p.getAllowFlight() || p.isFlying() || p.isGliding() || p.isRiptiding()
                || p.isInsideVehicle() || p.isSleeping() || p.isDead()
                || p.isInWater() || p.isInLava() || p.isSwimming()
                || p.hasPotionEffect(PotionEffectType.LEVITATION)
                || p.hasPotionEffect(PotionEffectType.SLOW_FALLING)
                || nearSpecialBlock(loc);

        if (cause) s.exemptUntil = Math.max(s.exemptUntil, tick + STICKY_TICKS);
        return cause;
    }

    private static boolean nearSpecialBlock(Location loc) {
        Block feet = loc.getBlock();
        Block[] around = {feet, feet.getRelative(BlockFace.UP), feet.getRelative(BlockFace.DOWN)};
        for (Block b : around) {
            Material m = b.getType();
            if (SPECIAL.contains(m) || Tag.CLIMBABLE.isTagged(m)) return true;
        }
        return false;
    }

    private static int jumpBoost(Player p) {
        PotionEffect effect = p.getPotionEffect(PotionEffectType.JUMP_BOOST);
        return effect == null ? 0 : effect.getAmplifier() + 1;
    }

    // ---------------------------------------------------------------- punishment

    private void flag(Player p, PlayerState s, int tick, String why, PlayerMoveEvent e, Location at) {
        FileConfiguration cfg = plugin.getConfig();
        double vl = s.model.vl();
        double dev = s.model.deviation();
        s.model.reset();

        if (tick - s.lastAlertTick >= 20) {
            s.lastAlertTick = tick;
            plugin.flagAlert("<white>" + p.getName() + "</white> <gray>failed fly <dark_gray>[</dark_gray>"
                    + "<yellow>" + why + "</yellow><dark_gray>]</dark_gray> "
                    + String.format(Locale.ROOT, "dev=%.3f vl=%.1f", dev, vl),
                    "<white>" + p.getName() + "</white> <gray>was flagged for <yellow>fly</yellow>");
        }
        if (!cfg.getBoolean("fly.punish", true)) return;

        Location back = setbackTarget(p, s, e != null ? e.getFrom() : at).clone();
        back.setYaw(at.getYaw());
        back.setPitch(at.getPitch());
        s.ownTeleport = true;
        if (e != null) e.setTo(back);
        else p.teleport(back);

        if (tick - s.lastSetbackTick > 1200) s.setbacks = 0;
        s.lastSetbackTick = tick;
        if (++s.setbacks >= cfg.getInt("fly.kick-after-setbacks", 4)) {
            s.setbacks = 0;
            p.kick(plugin.mm(cfg.getString("fly.kick-message", "<red>Kicked for flying.")));
        }
    }

    private static Location setbackTarget(Player p, PlayerState s, Location fallback) {
        if (s.lastGround != null && s.lastGround.getWorld() == p.getWorld()) return s.lastGround;
        return fallback;
    }

    // ---------------------------------------------------------------- things that legitimately move players

    private PlayerState state(Player p) {
        return states.computeIfAbsent(p.getUniqueId(), id -> new PlayerState(Bukkit.getCurrentTick()));
    }

    private void grace(Player p, int ticks) {
        PlayerState s = state(p);
        s.exemptUntil = Math.max(s.exemptUntil, Bukkit.getCurrentTick() + ticks);
    }

    /** Fired for knockback, explosions, wind charges, mace bursts, fishing rods, plugins calling setVelocity. */
    @EventHandler
    public void onVelocity(PlayerVelocityEvent e) {
        boolean launch = e.getVelocity().getY() > 0.1;
        grace(e.getPlayer(), launch ? plugin.getConfig().getInt("fly.launch-grace-ticks", 60) : 10);
    }

    @EventHandler
    public void onTeleport(PlayerTeleportEvent e) {
        PlayerState s = state(e.getPlayer());
        int grace = s.ownTeleport ? 2 : plugin.getConfig().getInt("fly.teleport-grace-ticks", 10);
        if (!s.ownTeleport) s.lastGround = null;
        s.ownTeleport = false;
        s.exemptUntil = Math.max(s.exemptUntil, Bukkit.getCurrentTick() + grace);
        s.model.unsettle();
    }

    /**
     * /fly: allow-flight is already exempt, but the client keeps flying for a moment after a plugin turns it off,
     * so give a window around the command. Covers /fly, /efly and namespaced forms like /essentials:fly.
     */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onFlyCommand(PlayerCommandPreprocessEvent e) {
        String raw = e.getMessage();
        if (!raw.startsWith("/")) return;
        int space = raw.indexOf(' ');
        String cmd = (space < 0 ? raw.substring(1) : raw.substring(1, space)).toLowerCase(Locale.ROOT);
        int colon = cmd.indexOf(':');
        if (colon >= 0) cmd = cmd.substring(colon + 1);
        if (cmd.equals("fly") || cmd.equals("efly") || cmd.equals("flight")) {
            grace(e.getPlayer(), plugin.getConfig().getInt("fly.fly-command-grace-ticks", 100));
            state(e.getPlayer()).model.unsettle();
        }
    }

    @EventHandler
    public void onToggleFlight(PlayerToggleFlightEvent e) {
        grace(e.getPlayer(), 40);
        state(e.getPlayer()).model.unsettle();
    }

    @EventHandler
    public void onRiptide(PlayerRiptideEvent e) {
        grace(e.getPlayer(), plugin.getConfig().getInt("fly.riptide-grace-ticks", 100));
    }

    @EventHandler
    public void onVehicleExit(VehicleExitEvent e) {
        if (e.getExited() instanceof Player p) {
            grace(p, STICKY_TICKS);
            state(p).model.unsettle();
        }
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        PlayerState s = state(e.getPlayer());
        s.lastGround = null;
        grace(e.getPlayer(), 40);
        s.model.unsettle();
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        states.put(e.getPlayer().getUniqueId(), new PlayerState(Bukkit.getCurrentTick()));
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        states.remove(e.getPlayer().getUniqueId());
    }
}
