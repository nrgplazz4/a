package dev.imnotlarpin.zenithac;

import static java.util.Map.entry;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * Decides whether a chat message contains a blocked word. No Bukkit types, so it can be tested on its own.
 *
 * Three kinds of words, because one matching rule can't be right for all of them:
 *  - strict:  checked on the message with spaces and symbols removed. Catches "n i g g e r" and "n.i.g.g.e.r".
 *             Only for words that never show up inside innocent text.
 *  - sub:     matched inside any single word ("fucking", "bitchy").
 *  - whole:   matched only as an entire word ("ass" must not hit "class" or "assist").
 *
 * Before matching, text is folded: accents, full-width and circled letters, zero-width characters, leetspeak and
 * Cyrillic/Greek lookalikes all collapse to plain a-z. Repeated letters are tolerated ("fuuuuck"), and a "*" in the
 * middle of a word counts as a wildcard ("f*ck", "ni**er").
 */
final class ChatScanner {

    private static final Pattern MARKS = Pattern.compile("\\p{M}+");
    private static final Pattern INVISIBLE =
            Pattern.compile("[\\u00AD\\u200B-\\u200F\\u202A-\\u202E\\u2060-\\u2064\\uFEFF]");
    private static final char MASK = '*';

    private static final Map<Character, Character> LOOKALIKES = Map.ofEntries(
            entry('0', 'o'), entry('1', 'i'), entry('!', 'i'), entry('|', 'i'), entry('3', 'e'),
            entry('4', 'a'), entry('@', 'a'), entry('5', 's'), entry('$', 's'), entry('7', 't'),
            entry('+', 't'), entry('9', 'g'),
            // Cyrillic
            entry('\u0430', 'a'), entry('\u0435', 'e'), entry('\u043E', 'o'), entry('\u0440', 'p'),
            entry('\u0441', 'c'), entry('\u0445', 'x'), entry('\u0443', 'y'), entry('\u0456', 'i'),
            entry('\u0455', 's'),
            // Greek
            entry('\u03BF', 'o'), entry('\u03B1', 'a'), entry('\u03B5', 'e'), entry('\u03B9', 'i'),
            entry('\u03BD', 'v'), entry('\u03BA', 'k'));

    private final List<String> strictWords;
    private final List<String> subWords;
    private final List<String> wholeWords;
    private final List<Pattern> strictPatterns;
    private final List<Pattern> subPatterns;
    private final List<Pattern> wholePatterns;
    private final Set<String> allowed = new HashSet<>();

    ChatScanner(Collection<String> strict, Collection<String> sub, Collection<String> whole,
                Collection<String> allowed) {
        this.strictWords = clean(strict);
        this.subWords = clean(sub);
        this.wholeWords = clean(whole);
        this.strictPatterns = repeating(strictWords, false);
        this.subPatterns = repeating(subWords, false);
        this.wholePatterns = repeating(wholeWords, true);
        this.allowed.addAll(clean(allowed));
    }

    boolean isBlocked(String message) {
        List<String> tokens = tokens(normalize(message));
        tokens.removeIf(allowed::contains);

        StringBuilder squash = new StringBuilder();
        for (String t : tokens) {
            for (int i = 0; i < t.length(); i++) {
                char c = t.charAt(i);
                if (c >= 'a' && c <= 'z') squash.append(c);
            }
        }
        String squashed = squash.toString();
        String squashedQ = squashed.replace('q', 'g'); // "niqqa"
        for (Pattern p : strictPatterns) {
            if (p.matcher(squashed).find() || p.matcher(squashedQ).find()) return true;
        }

        for (String t : tokens) {
            if (t.indexOf(MASK) >= 0) {
                for (String w : strictWords) if (maskedContains(t, w)) return true;
                for (String w : subWords) if (maskedContains(t, w)) return true;
                for (String w : wholeWords) if (maskedEquals(t, w)) return true;
                continue;
            }
            for (Pattern p : subPatterns) if (p.matcher(t).find()) return true;
            for (Pattern p : wholePatterns) if (p.matcher(t).matches()) return true;
        }
        return false;
    }

    static String normalize(String in) {
        String s = Normalizer.normalize(in, Normalizer.Form.NFKD);
        s = MARKS.matcher(s).replaceAll("");
        s = INVISIBLE.matcher(s).replaceAll("");
        s = s.toLowerCase(Locale.ROOT);
        StringBuilder sb = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            Character mapped = LOOKALIKES.get(c);
            sb.append(mapped != null ? mapped : c);
        }
        return sb.toString();
    }

    /** Words, with runs of single letters ("f u c k", "f.u.c.k") glued back together. */
    static List<String> tokens(String s) {
        List<String> out = new ArrayList<>();
        StringBuilder run = new StringBuilder();
        for (String raw : s.split("[^a-z*]+")) {
            String t = trimMasks(raw);
            if (t.isEmpty()) continue;
            if (t.length() == 1) {
                run.append(t);
                continue;
            }
            if (run.length() > 0) {
                out.add(run.toString());
                run.setLength(0);
            }
            out.add(t);
        }
        if (run.length() > 0) out.add(run.toString());
        return out;
    }

    private static String trimMasks(String t) {
        int a = 0, b = t.length();
        while (a < b && t.charAt(a) == MASK) a++;
        while (b > a && t.charAt(b - 1) == MASK) b--;
        return t.substring(a, b);
    }

    private static boolean maskedContains(String token, String word) {
        for (int i = 0; i + word.length() <= token.length(); i++) {
            int j = 0;
            while (j < word.length() && (token.charAt(i + j) == word.charAt(j) || token.charAt(i + j) == MASK)) j++;
            if (j == word.length()) return true;
        }
        return false;
    }

    private static boolean maskedEquals(String token, String word) {
        if (token.length() != word.length()) return false;
        return maskedContains(token, word);
    }

    private static List<String> clean(Collection<String> words) {
        List<String> out = new ArrayList<>();
        for (String w : words) {
            String c = w.toLowerCase(Locale.ROOT).replaceAll("[^a-z]", "");
            if (!c.isEmpty()) out.add(c);
        }
        return out;
    }

    /** "fuck" becomes f+u+c+k+ so stretched spellings still match. */
    private static List<Pattern> repeating(List<String> words, boolean whole) {
        List<Pattern> out = new ArrayList<>();
        for (String w : words) {
            StringBuilder sb = new StringBuilder(whole ? "^" : "");
            for (char c : w.toCharArray()) sb.append(c).append('+');
            if (whole) sb.append('$');
            out.add(Pattern.compile(sb.toString()));
        }
        return out;
    }
}
