package dev.imnotlarpin.zenithac;

/**
 * Vertical movement model for a vanilla player. No Bukkit types on purpose, so it can be tested without a server.
 *
 * A vanilla client sends one position packet per tick while its position is changing, and an airborne player's
 * position always changes (gravity). So while someone is in the air, every call to {@link #onMove} is exactly one
 * tick of physics, and we never have to guess at tick gaps (which server lag would wreck). The only question asked
 * each tick is: could gravity have produced this dy, given last tick's dy?
 *
 * Vanilla order each tick: move by vy, then vy = (vy - 0.08) * 0.98. A jump sets vy to 0.42 before moving.
 * Only movement that is higher than physics allows is flagged. Moving less than predicted is normal (ceilings).
 */
final class FlyModel {

    enum Result { OK, JUMP, PHYSICS }

    static final double GRAVITY = 0.08;
    static final double DRAG = 0.98;
    static final double JUMP_VELOCITY = 0.42;

    private double lastDy;
    private boolean wasGround = true;
    private int skip = 2;
    private double vl;
    private double deviation;

    /** Initial jump velocity, including Jump Boost (level 1 = Jump Boost I). */
    static double jumpVelocity(int boostLevel) {
        return JUMP_VELOCITY + 0.1 * boostLevel;
    }

    /** The dy gravity produces on the tick after one that moved by lastDy. */
    static double nextDy(double lastDy) {
        return (lastDy - GRAVITY) * DRAG;
    }

    /**
     * @param dy        vertical change since the previous position packet
     * @param ground    whether the server's own collision check says the player is standing on something
     * @param exempt    flying, gliding, in water, on a ladder, just knocked back, etc. Tracked but never flagged.
     * @param tolerance how much higher than physics a move may be before it counts
     */
    Result onMove(double dy, boolean ground, int boostLevel, boolean exempt, double tolerance) {
        Result result = Result.OK;
        deviation = 0;

        if (exempt) {
            // keep tracking so the first checked move afterwards has a baseline
        } else if (skip > 0) {
            skip--;
        } else if (!ground) {
            if (wasGround) {
                // First airborne tick: either stepped off a ledge (dy < 0) or jumped (dy <= jump velocity).
                deviation = dy - jumpVelocity(boostLevel);
                if (deviation > tolerance) result = Result.JUMP;
            } else {
                deviation = dy - nextDy(lastDy);
                if (deviation > tolerance) result = Result.PHYSICS;
            }
        }

        if (!exempt && skip == 0) {
            switch (result) {
                // Bigger impossibilities weigh more: one mid-air double jump is conclusive, a 0.04 wobble is not.
                case JUMP -> vl += 2 + Math.min(3, deviation * 8);
                case PHYSICS -> vl += 1 + Math.min(4, deviation * 8);
                case OK -> vl = Math.max(0, vl - (ground ? 0.25 : 0.05));
            }
        }

        lastDy = dy;
        wasGround = ground;
        return result;
    }

    /** A player who is airborne but has stopped sending position packets (hovering perfectly still). */
    void stall() {
        vl += 1;
        deviation = 0;
    }

    /** Forget the baseline for a couple of moves (teleport, dismounting, end of an exemption). Keeps violations. */
    void unsettle() {
        skip = 2;
    }

    /** Clear everything, e.g. after a setback. */
    void reset() {
        vl = 0;
        deviation = 0;
        skip = 2;
    }

    double vl() {
        return vl;
    }

    double deviation() {
        return deviation;
    }
}
