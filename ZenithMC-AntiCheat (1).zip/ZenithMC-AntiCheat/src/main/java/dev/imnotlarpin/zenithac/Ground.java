package dev.imnotlarpin.zenithac;

import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Boat;
import org.bukkit.entity.Minecart;
import org.bukkit.entity.Shulker;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.VoxelShape;

/**
 * Server-side "is this player standing on something". Never trusts the client's onGround flag.
 * Uses real collision shapes, so fences (1.5 tall), slabs, carpets, soul sand etc. all work.
 */
final class Ground {

    private Ground() {
    }

    static boolean standing(Location l) {
        World w = l.getWorld();
        return onBlock(w, l.getX(), l.getY(), l.getZ()) || onEntity(w, l.getX(), l.getY(), l.getZ());
    }

    /** A thin slab under the 0.6 wide player hitbox overlaps some block's collision shape. */
    static boolean onBlock(World w, double x, double y, double z) {
        BoundingBox box = new BoundingBox(x - 0.3, y - 0.08, z - 0.3, x + 0.3, y + 0.001, z + 0.3);
        int x0 = floor(box.getMinX()), x1 = floor(box.getMaxX());
        int z0 = floor(box.getMinZ()), z1 = floor(box.getMaxZ());
        // One block lower than the slab: fences and walls collide up to 1.5 blocks above their own block.
        int y0 = floor(box.getMinY()) - 1, y1 = floor(box.getMaxY());

        for (int bx = x0; bx <= x1; bx++) {
            for (int bz = z0; bz <= z1; bz++) {
                if (!w.isChunkLoaded(bx >> 4, bz >> 4)) continue;
                for (int by = y0; by <= y1; by++) {
                    Block b = w.getBlockAt(bx, by, bz);
                    if (b.isPassable()) continue; // air, water, grass... no collision
                    VoxelShape shape = b.getCollisionShape();
                    if (shape.overlaps(box.clone().shift(-bx, -by, -bz))) return true;
                }
            }
        }
        return false;
    }

    /** Players can stand on boats, minecarts, shulkers and armor stands. */
    static boolean onEntity(World w, double x, double y, double z) {
        BoundingBox box = new BoundingBox(x - 0.3, y - 0.5, z - 0.3, x + 0.3, y + 0.05, z + 0.3);
        return !w.getNearbyEntities(box, e ->
                e instanceof Boat || e instanceof Minecart || e instanceof Shulker || e instanceof ArmorStand
        ).isEmpty();
    }

    private static int floor(double v) {
        return (int) Math.floor(v);
    }
}
