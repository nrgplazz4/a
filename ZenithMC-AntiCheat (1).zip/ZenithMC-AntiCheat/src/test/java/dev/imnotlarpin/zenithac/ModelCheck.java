package dev.imnotlarpin.zenithac;

import java.util.ArrayList;
import java.util.List;

/**
 * Plain-main check for the fly model: legit vanilla trajectories must never flag, known hacks must.
 * Run with: java -cp target/classes:target/test-classes dev.imnotlarpin.zenithac.ModelCheck
 */
public final class ModelCheck {

    private static final double TOL = 0.03;
    private static final double THRESHOLD = 5.0;
    private static int failures;

    record Step(double dy, boolean ground) {}

    /** Vanilla physics written out independently of FlyModel: move by v, then v = (v - 0.08) * 0.98. */
    static List<Step> jump(double v0) {
        List<Step> out = new ArrayList<>();
        double y = 0, v = v0;
        while (true) {
            double dy = v;
            y += dy;
            boolean ground = false;
            if (y <= 0) {
                dy -= y;
                y = 0;
                ground = true;
            }
            out.add(new Step(dy, ground));
            if (ground) return out;
            v = (v - 0.08) * 0.98;
        }
    }

    static List<Step> fall(double startHeight) {
        List<Step> out = new ArrayList<>();
        double y = startHeight, v = -0.0784;
        while (true) {
            double dy = v;
            y += dy;
            boolean ground = false;
            if (y <= 0) {
                dy -= y;
                y = 0;
                ground = true;
            }
            out.add(new Step(dy, ground));
            if (ground) return out;
            v = (v - 0.08) * 0.98;
        }
    }

    public static void main(String[] args) {
        // Sanity-check the simulator itself against well-known vanilla numbers.
        List<Step> j = jump(0.42);
        double peak = 0, y = 0;
        for (Step s : j) {
            y += s.dy();
            peak = Math.max(peak, y);
        }
        expect("vanilla jump peak is ~1.2522", Math.abs(peak - 1.2522) < 0.001);
        expect("vanilla jump lasts 12 ticks", j.size() == 12);

        // Legit movement must never flag.
        for (int boost = 0; boost <= 5; boost++) {
            double v0 = 0.42 + 0.1 * boost;
            legit("jump, boost " + boost, boost, concat(standing(4), jump(v0), standing(4)));
        }
        legit("fall off a ledge, 1 block", 0, concat(standing(4), fall(1), standing(2)));
        legit("fall off a ledge, 40 blocks", 0, concat(standing(4), fall(40), standing(2)));
        legit("bunny hop x5", 0, concat(standing(2), jump(0.42), jump(0.42), jump(0.42), jump(0.42), jump(0.42)));

        // Exemption (knockback etc.): wild dy while exempt, then plain physics once it ends.
        {
            FlyModel m = new FlyModel();
            double maxVl = 0;
            for (Step s : standing(4)) m.onMove(s.dy(), s.ground(), 0, false, TOL);
            double v = 1.3; // launched upwards
            for (int i = 0; i < 10; i++) {
                m.onMove(v, false, 0, true, TOL);
                v = (v - 0.08) * 0.98;
            }
            m.unsettle(); // what FlyCheck does when an exemption ends
            for (int i = 0; i < 40; i++) {
                maxVl = Math.max(maxVl, m.vl());
                if (m.onMove(v, false, 0, false, TOL) != FlyModel.Result.OK) maxVl = 99;
                v = (v - 0.08) * 0.98;
            }
            expect("launch then free fall after exemption ends: no flags", maxVl == 0);
        }

        // Hacks must reach the flag threshold quickly.
        detect("hover right after jumping", hover(3, 20), 12);
        detect("hover at jump apex", hover(6, 20), 12);
        detect("hover from the ground up", hover(0, 20), 10);
        detect("steady ascent 0.2/tick", rise(0.2, 20), 10);
        detect("steady ascent 0.05/tick", rise(0.05, 30), 12);
        detect("glide at -0.05/tick", glide(-0.05, 30), 12);
        detect("slow fall at -0.02/tick", glide(-0.02, 30), 12);
        detectFrom("mid-air double jump", doubleJump(), 4 + 8, 1);

        // Jump boost the player doesn't have.
        {
            FlyModel m = new FlyModel();
            for (Step s : standing(4)) m.onMove(s.dy(), s.ground(), 0, false, TOL);
            boolean flagged = false;
            for (Step s : jump(0.42 + 0.1 * 4)) {
                if (m.onMove(s.dy(), s.ground(), 0, false, TOL) == FlyModel.Result.JUMP) flagged = true;
            }
            expect("high jump without Jump Boost is flagged", flagged);
        }

        // Stationary hover (no packets) is handled by stall(): five stalls reach the threshold.
        {
            FlyModel m = new FlyModel();
            for (int i = 0; i < 5; i++) m.stall();
            expect("stall x5 reaches threshold", m.vl() >= THRESHOLD);
        }

        // Occasional noise must decay instead of building up forever.
        {
            FlyModel m = new FlyModel();
            for (Step s : standing(4)) m.onMove(s.dy(), s.ground(), 0, false, TOL);
            m.stall();
            m.stall();
            for (Step s : concat(jump(0.42), standing(8))) m.onMove(s.dy(), s.ground(), 0, false, TOL);
            expect("violations decay on the ground", m.vl() < 1.0);
        }

        System.out.println("fly model checks done, " + failures + " failures");
        System.exit(failures == 0 ? 0 : 1);
    }

    static List<Step> standing(int n) {
        List<Step> out = new ArrayList<>();
        for (int i = 0; i < n; i++) out.add(new Step(0, true));
        return out;
    }

    @SafeVarargs
    static List<Step> concat(List<Step>... parts) {
        List<Step> out = new ArrayList<>();
        for (List<Step> p : parts) out.addAll(p);
        return out;
    }

    static List<Step> hover(int ticksOfJumpFirst, int hoverTicks) {
        List<Step> out = new ArrayList<>(standing(4));
        List<Step> j = jump(0.42);
        for (int i = 0; i < ticksOfJumpFirst; i++) out.add(j.get(i));
        for (int i = 0; i < hoverTicks; i++) out.add(new Step(0, false));
        return out;
    }

    static List<Step> rise(double dy, int ticks) {
        List<Step> out = new ArrayList<>(standing(4));
        out.add(new Step(0.42, false));
        for (int i = 0; i < ticks; i++) out.add(new Step(dy, false));
        return out;
    }

    static List<Step> glide(double dy, int ticks) {
        List<Step> out = new ArrayList<>(standing(4));
        List<Step> j = jump(0.42);
        for (int i = 0; i < 8; i++) out.add(j.get(i));
        for (int i = 0; i < ticks; i++) out.add(new Step(dy, false));
        return out;
    }

    static List<Step> doubleJump() {
        List<Step> out = new ArrayList<>(standing(4));
        List<Step> j = jump(0.42);
        for (int i = 0; i < 8; i++) out.add(j.get(i));
        for (Step s : jump(0.42)) out.add(new Step(s.dy(), false));
        return out;
    }

    static void legit(String name, int boost, List<Step> steps) {
        FlyModel m = new FlyModel();
        double maxVl = 0;
        int flags = 0;
        for (Step s : steps) {
            if (m.onMove(s.dy(), s.ground(), boost, false, TOL) != FlyModel.Result.OK) flags++;
            maxVl = Math.max(maxVl, m.vl());
        }
        expect("legit: " + name, flags == 0 && maxVl == 0);
    }

    static void detect(String name, List<Step> steps, int withinTicks) {
        detectFrom(name, steps, 4, withinTicks); // the 4 standing ticks come first
    }

    static void detectFrom(String name, List<Step> steps, int hackStart, int withinTicks) {
        FlyModel m = new FlyModel();
        int flaggedAt = -1;
        for (int i = 0; i < steps.size(); i++) {
            Step s = steps.get(i);
            m.onMove(s.dy(), s.ground(), 0, false, TOL);
            if (m.vl() >= THRESHOLD && flaggedAt < 0) flaggedAt = i - hackStart;
        }
        expect("hack: " + name + (flaggedAt >= 0 ? " (flagged after " + flaggedAt + " ticks)" : " (NOT flagged)"),
                flaggedAt >= 0 && flaggedAt <= withinTicks);
    }

    static void expect(String what, boolean ok) {
        if (!ok) failures++;
        System.out.println((ok ? "ok    " : "FAIL  ") + what);
    }
}
