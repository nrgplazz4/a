package dev.imnotlarpin.zenithac;

import java.util.List;

/** Plain-main check, run with: java -cp target/classes:target/test-classes dev.imnotlarpin.zenithac.ScannerCheck */
public final class ScannerCheck {

    private static int failures;

    public static void main(String[] args) {
        ChatScanner s = new ChatScanner(
                List.of("nigg", "fuck"),
                List.of("fuck", "shit", "bitch", "asshole", "asshat", "bastard", "whore", "piss"),
                List.of("ass", "asses", "dick", "dicks", "cock", "cocks", "cunt", "cunts", "pussy", "slut",
                        "fuk", "fck", "fuq"),
                List.of("shiitake", "shitake", "snigger", "sniggering", "niggle", "niggling"));

        String[] mustBlock = {
                "nigger", "NIGGA", "N1GG3R", "n!gg3r", "n i g g e r", "n.i.g.g.e.r", "nnniiiggggeeerrr",
                "ni**er", "n*gger", "niqqa", "\uFF4E\uFF49\uFF47\uFF47\uFF45\uFF52", "n\u200Bigger", "n\u0456gger",
                "you are a nigger lol",
                "fuck", "FUUUUCK", "f u c k", "f.u.c.k", "f*ck", "fuk", "what the f u c k", "fucking idiot",
                "sh1t", "$hit", "shiiit", "what a shitty day", "bitch", "b!tch", "b*tch", "bitchy",
                "asshole", "a$$", "@ss", "a s s", "you ass", "dick", "d1ck", "cunt", "c*nt", "pussy",
                "go piss off", "whore", "\u0455hit"
        };
        String[] mustAllow = {
                "hello world", "gg ez", "I love Scunthorpe", "class", "assist", "assassin", "pass the salt",
                "grass is green", "cocktail", "peacock", "Hancock", "Dickens", "Dickinson", "night", "knight",
                "Niger", "Nigeria", "tonight", "this hit the spot", "shiitake mushrooms", "snigger", "niggle",
                "bass guitar", "analysis", "button", "classic", "Mississippi", "a bit chilly", "I'm at spawn x:100 z:-50",
                "buy 5*3 stacks", "sell 64 diamonds for 3.5k", "who wants to trade", "Assassin's Creed",
                "that was a great build", "come to /warp shop", "puffin", "assembly", "associate", "compass",
                "I have 3 shulkers", "hit me up", "bitten by a spider", "skipping class", "Essex", "Sussex"
        };

        for (String m : mustBlock) check("block", m, s.isBlocked(m), true);
        for (String m : mustAllow) check("allow", m, s.isBlocked(m), false);

        System.out.println((mustBlock.length + mustAllow.length) + " cases, " + failures + " failures");
        System.exit(failures == 0 ? 0 : 1);
    }

    private static void check(String kind, String msg, boolean actual, boolean expected) {
        if (actual != expected) {
            failures++;
            System.out.println("FAIL (" + kind + "): \"" + msg + "\" -> blocked=" + actual);
        }
    }
}
