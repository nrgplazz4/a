# ZenithMC Anti Cheat

By imnotlarpin.

Anti-fly and a chat filter for Paper 1.21.11. Build with `mvn package`, drop `target/ZenithMC-AntiCheat.jar` in `plugins/`.
Anti-xray (the "can't see below" part) is Paper's own, see `paper-anti-xray.yml`.

## Fly check

A vanilla client sends one position packet per tick while its position changes. An airborne player always moves
(gravity), so each move event while airborne is exactly one tick of physics. The check asks one question per tick:
could gravity have produced this dy, given the last one? Vanilla order: move by vy, then vy = (vy - 0.08) * 0.98;
a jump starts at 0.42 (+0.1 per Jump Boost level).

- Ground is decided on the server with real collision shapes. The client's onGround flag is never trusted.
- Only movement higher than physics allows is flagged. Hovering, gliding, slow fall, steady climbing, mid-air
  jumps and Jump Boost the player doesn't have all fail this. Bigger impossibilities add more violation points.
- Perfect hovering sends no packets at all, so a separate task catches airborne players who went silent.
- Exempt: operators (`fly.exempt-ops`), creative/spectator, allow-flight, elytra, riptide, vehicles, water, lava, ladders/vines, cobweb, honey,
  powder snow, bubble columns, levitation, slow falling, knockback/explosions/wind charges (PlayerVelocityEvent),
  teleports, `/fly` (plus a window around the command so turning it off mid-air never flags), and a few seconds after standing on slime or a bed. Players can stand on boats, minecarts, shulkers
  and armor stands.
- When someone is flagged, a short line goes to everyone in chat (`alerts.broadcast-flags`); staff with
  `zenithac.alerts` get the detailed one.
- A flag puts the player back on their last verified ground position. Repeated flags kick.

Not covered: horizontal speed, bhop, boat/elytra tricks, no-fall. This is a fly check, not a full anti-cheat.

**First day on a live server:** set `fly.punish: false` and watch the staff alerts. Odd setups (piston launchers,
custom plugins that move players without setVelocity, Bedrock players through Geyser) can need exemptions. Give
those players `zenithac.bypass` or raise `fly.tolerance` slightly.

## Chat filter

Words are matched after folding accents, full-width letters, zero-width characters, leetspeak and Cyrillic/Greek
lookalikes. Three lists, because one rule can't fit every word:

- `strict-words`: checked with spaces and symbols stripped ("n i g g e r"). Only for words that never appear in
  innocent text.
- `cuss-substring`: matched inside any word.
- `cuss-whole`: whole words only, so "class" and "assist" pass.

Stretched letters ("fuuuck") match, and `*` in the middle of a word is a wildcard ("f*ck", "ni**er").
Also filters `/msg`-style commands and signs. Three strikes in ten minutes mutes; mutes survive restarts.
`/zenithac unmute <player>`, `/zenithac reload`.

It will not catch every spelling of every slur. Add what you see to the lists.

## Checks

The movement model and chat scanner have no Bukkit dependency and come with plain-main checks:

    mvn -q package
    java -cp target/classes:target/test-classes dev.imnotlarpin.zenithac.ModelCheck
    java -cp target/classes:target/test-classes dev.imnotlarpin.zenithac.ScannerCheck

## Getting the jar without installing anything

Create a free GitHub repo, upload the contents of this folder (including the hidden `.github` folder), open the
Actions tab, and run "Build plugin". When it finishes, download the `ZenithMC-AntiCheat` artifact: that zip holds
`ZenithMC-AntiCheat.jar`. Put the jar in `plugins/`.
